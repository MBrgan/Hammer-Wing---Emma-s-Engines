﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Payment
    {
        public int PaymentID { get; set; }

        [Display(Name = "Payment Type")]
        [Required(ErrorMessage = "You cannot payment type blank")]
        public string PaymentType { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "You cannot description type blank")]
        public string OtherDescription { get; set; }
        public ICollection<InvoicePayment> InvoicePayments { get; set; } = new HashSet<InvoicePayment>();
    }
}
