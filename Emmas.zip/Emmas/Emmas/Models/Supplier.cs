﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Supplier
    {
        public int supID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "You cannot leave name blank")]
        public string supName { get; set; }

        [Required(ErrorMessage = "You cannot leave phone number blank")]
        [RegularExpression("^\\d{10}$", ErrorMessage = "Please enter a valid 10-digit phone number (no spaces)")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(10)]
        public string supPhone { get; set; }

        [Required(ErrorMessage = "You cannot leave email address blank")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string supEmail { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "You cannot leave address blank")]
        public string supAddress { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "You cannot leave city blank")]
        public string supCity { get; set; }

        [Display(Name = "Province")]
        [Required(ErrorMessage = "You cannot leave province blank")]
        public string supProvince { get; set; }

        [Display(Name = "Postal Code")]
        [Required(ErrorMessage = "You cannot leave postal code blank")]
        [RegularExpression("/^[ABCEGHJ-NPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z]\\d[ABCEGHJ-NPRSTV-Z]\\d$/i", ErrorMessage = "Please enter a valid postal code (no space)")]
        public string supPostal { get; set; }
        public ICollection<Price> Prices { get; set; } = new HashSet<Price>();
    }
}
