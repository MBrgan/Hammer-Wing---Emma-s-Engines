﻿namespace Emmas.Models
{
    public class EmployeePosition
    {
        public int EmpID { get; set; }
        public Employee Employee { get; set; }

        public string PosTitle { get; set; }
        public Position Position { get; set; }
    }
}
