﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class EmpLogins
    {
        public int LogID { get; set; }

        public DateTime SignIn { get; set; }

        public DateTime SignOut { get; set; }

        public int EmpID { get; set; }
        public Employee Employee { get; set; }
    }
}
