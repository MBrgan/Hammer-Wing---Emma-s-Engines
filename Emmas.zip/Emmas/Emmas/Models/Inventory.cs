﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Inventory
    {
        [Display(Name = "UPC")]
        [Required(ErrorMessage = "You cannot leave UPC blank")]
        public string UPC { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "You cannot leave name blank")]
        public string invName { get; set; }

        [Display(Name = "Size")]
        [Required(ErrorMessage = "You cannot leave size blank")]
        public string invSize { get; set; }

        [Display(Name = "quantity")]
        [Required(ErrorMessage = "You cannot leave quantity blank")]
        public int invQuantity { get; set; }

        [Display(Name = "Adjusted price")]
        [Required(ErrorMessage = "You cannot leave adjusted price blank")]
        public double invAdjustedPrice { get; set; }

        [Display(Name = "Markup Price")]
        [Required(ErrorMessage = "You cannot leave markup price blank")]
        public double invMarkupPrice { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "You cannot leave description blank")]
        public int invCurrent { get; set; }

        public ICollection<Price> Prices { get; set; } = new HashSet<Price>();

        public InvoiceLine InvoiceLine { get; set; }
    }
}
