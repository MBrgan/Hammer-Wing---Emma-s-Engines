﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Employee
    {
        public int EmpID { get; set; }

        [Display(Name = "Employee")]
        public string EmpFull
        {
            get
            {
                return EmpFirst + " " + EmpLast;
            }
        }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "You cannot leave first name blank.")]
        public string EmpFirst { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "You cannot leave last name blank.")]
        public string EmpLast { get; set; }

        [Display(Name = "Username")]
        [Required(ErrorMessage = "You cannot leave Username blank.")]
        public string EmpUserName { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "You cannot leave Password blank.")]
        public string EmpPassword { get; set; }

        [Display(Name = "Employees")]
        public ICollection<EmpLogins> EmpLogins { get; set; } = new HashSet<EmpLogins>();

        [Display(Name = "Employee Positions")]
        public ICollection<EmployeePosition> EmployeePositions { get; set; } = new HashSet<EmployeePosition>();

        [Display(Name = "Invoices")]
        public ICollection<Invoice> Invoices { get; set; } = new HashSet<Invoice>();
    }
}
