﻿using System.ComponentModel.DataAnnotations;

namespace Emmas.Models
{
    public class OrderRequest
    {
        public int orderRequestID { get; set; }

        public Customer Customer { get; set; }
        public int custID { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "You cannot leave description blank")]
        public string oReqDescription { get; set; }

        [Required(ErrorMessage = "You must enter the order request send date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime oReqSentDate { get; set; }

        [Required(ErrorMessage = "You must enter the order request send date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime oReqReceiveDate { get; set; }

        [Display(Name = "Order Number")]
        [Required(ErrorMessage = "You cannot leave order number cost blank")]
        public string externalOrderNum { get; set; }

        public OrderRequestInventory OrderRequestInventory { get; set; }
    }
}
