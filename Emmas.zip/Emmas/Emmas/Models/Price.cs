﻿using System.ComponentModel.DataAnnotations;

namespace Emmas.Models
{
    public class Price
    {
        public int priceID { get; set; }
        
        public Inventory Inventory { get; set; }
        public string UPC { get; set; }

        [Display(Name = "Purchase Cost")]
        [Required(ErrorMessage = "You cannot leave purchase cost blank")]
        public double pricePurchasedCost { get; set; }

        [Required(ErrorMessage = "You must enter the purchase date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime pricePurchasedDate { get; set; }

        [Display(Name = "Count")]
        [Required(ErrorMessage = "You cannot leave count blank")]
        public int priceCount { get; set; }

        public Supplier Supplier { get; set; }
        public int supID { get; set; }
    }
}
