﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class InvoiceLine
    {
        public int invoiceID { get; set; }
        public Invoice Invoice { get; set; }

        public string UPC { get; set; }
        public Inventory Inventory { get; set; }

        [Display(Name = "Quantity")]
        [Required(ErrorMessage = "You cannot leave quantity blank")]
        public int odQuantity { get; set; }

        [Display(Name = "Sale Price")]
        [Required(ErrorMessage = "You cannot leave sale price blank")]
        public int odSalePrice { get; set; }
    }
}
