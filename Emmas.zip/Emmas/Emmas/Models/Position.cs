﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Position
    {
        public string PosTitle { get; set; }

        [Display(Name = "Employee Positions")]
        public ICollection<EmployeePosition> EmployeePositions { get; set; } = new HashSet<EmployeePosition>();
    }
}
