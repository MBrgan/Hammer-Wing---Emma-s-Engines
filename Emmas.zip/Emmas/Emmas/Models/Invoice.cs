﻿using System.ComponentModel.DataAnnotations;

namespace Emmas.Models
{
    public class Invoice
    {
        public int InvoiceID { get; set; }

        [Required(ErrorMessage = "You must enter the InvoiceDate")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime InvoiceDate { get; set; }

        [Display(Name = "Appreciation")]
        [Required(ErrorMessage = "You cannot leave appreciation blank")]
        public string Appreciation { get; set; }

        [Display(Name = "Description")]
        [Required(ErrorMessage = "You cannot leave description blank")]
        public string Description { get; set; }

        [Display(Name = "Subtotal")]
        [Required(ErrorMessage = "You cannot leave subtotal blank")]
        public double InvoiceSubtotal { get; set; }

        public int CustID { get; set; }
        public Customer Customer { get; set; }

        public int EmpID { get; set; }
        public Employee Employee { get; set; }

        public InvoiceLine InvoiceLine { get; set; }

        public ICollection<InvoicePayment> InvoicePayments { get; set; } = new HashSet<InvoicePayment>();
    }
}
