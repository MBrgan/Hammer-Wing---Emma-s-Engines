﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Emmas.Models
{
    public class Customer
    {
        public int CustID { get; set; }

        [Display(Name = "Customer")]
        public string CustFull
        {
            get{
                return CustFirst + " " + CustLast;
            }
        }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "You cannot leave first name blank")]
        public string CustFirst { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "You cannot leave last name blank")]
        public string CustLast { get; set; }

        [Display(Name = "Phone Number")]
        [Required(ErrorMessage = "You cannot leave phone number blank")]
        [RegularExpression("^\\d{10}$", ErrorMessage = "Please enter a valid 10-digit phone number (no spaces)")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(10)]
        public string CustPhone { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "You cannot leave address blank")]
        public string CustAddress { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "You cannot leave city blank")]
        public string CustCity { get; set; }

        [Display(Name = "Province")]
        [Required(ErrorMessage = "You cannot leave province blank")]
        public string CustProvince { get; set; }

        [Display(Name = "Postal Code")]
        [Required(ErrorMessage = "You cannot leave postal code blank")]
        [RegularExpression("/^[ABCEGHJ-NPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z]\\d[ABCEGHJ-NPRSTV-Z]\\d$/i", ErrorMessage = "Please enter a valid postal code (no space)")]
        public string CustPostal { get; set; }
        public ICollection<Invoice> Invoices { get; set; } = new HashSet<Invoice>();
        public ICollection<OrderRequest> OrderRequests { get; set; } = new HashSet<OrderRequest>();
    }
}
