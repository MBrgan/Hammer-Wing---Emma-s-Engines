﻿namespace Emmas.Models
{
    public class OrderRequestInventory
    {
        public int ordRequestID { get; set; }
        public OrderRequest OrderRequest { get; set; }

        public string UPC { get; set; }
        public Inventory Inventory { get; set; }
    }
}
