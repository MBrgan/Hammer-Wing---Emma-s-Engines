﻿namespace Emmas.Models
{
    public class InvoicePayment
    {
        public string InvoiceID { get; set; }
        public Invoice Invoice { get; set; }

        public string PaymentID { get; set; }
        public Payment Payment { get; set; }
    }
}
